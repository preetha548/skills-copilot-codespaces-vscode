// Notes App functionality
let notesArray = JSON.parse(localStorage.getItem("notes")) || [];

const noteForm = document.getElementById('note-form');
const noteText = document.getElementById('note-text');
const noteTags = document.getElementById('note-tags');
const notesList = document.getElementById('notes-list');
const searchBar = document.getElementById('search-bar');

// Load notes from local storage when the page is loaded
window.onload = function () {
    renderNotes();
};

// Add new note
document.getElementById('add-note').addEventListener('click', function() {
    const content = noteText.value.trim();
    const tags = noteTags.value.trim().split(',').map(tag => tag.trim()).filter(tag => tag !== '');

    if (content) {
        const newNote = {
            content,
            tags,
            id: Date.now()
        };

        notesArray.push(newNote);
        localStorage.setItem("notes", JSON.stringify(notesArray));

        noteText.value = '';
        noteTags.value = '';

        renderNotes();
    } else {
        alert("Please write something before adding!");
    }
});

// Render notes to the DOM
function renderNotes(searchQuery = '') {
    notesList.innerHTML = '';

    const filteredNotes = notesArray.filter(note => {
        return note.content.toLowerCase().includes(searchQuery.toLowerCase());
    });

    filteredNotes.forEach(note => {
        const noteDiv = document.createElement('div');
        noteDiv.classList.add('note');

        noteDiv.innerHTML = `
            <p class="note-content">${note.content}</p>
            <div class="note-tags">
                ${note.tags.map(tag => `<span>${tag}</span>`).join('')}
            </div>
            <button class="delete-note" onclick="deleteNote(${note.id})">X</button>
        `;

        notesList.appendChild(noteDiv);
    });
}

// Delete note
function deleteNote(id) {
    notesArray = notesArray.filter(note => note.id !== id);
    localStorage.setItem("notes", JSON.stringify(notesArray));
    renderNotes();
}

// Search functionality
searchBar.addEventListener('input', function() {
    renderNotes(searchBar.value);
});