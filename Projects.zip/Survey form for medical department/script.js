/* 
CSS Style sheet
Ver. 2.0
Print ready and CSS ready to optimize
Author: Nishant Dogra
Initial built: 04-01-2018
Updated: 16-02-2018
*/